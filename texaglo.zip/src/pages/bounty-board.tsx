import BountyBoard from "@/views/BountyBoard";
import React from "react";

const BountyBoardPage = () => {
  return (
    <>
      <BountyBoard />
    </>
  );
};

export default BountyBoardPage;
