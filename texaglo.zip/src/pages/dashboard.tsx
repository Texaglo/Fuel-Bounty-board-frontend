import PostABounty from "@/views/PostABounty";

const DashboardPage = () => {
  return (
    <>
      <PostABounty />
    </>
  );
};

export default DashboardPage;
