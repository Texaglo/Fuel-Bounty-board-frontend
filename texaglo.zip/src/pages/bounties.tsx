import Bounties from "@/views/Bounties";

const BountiesPage = () => {
  return (
    <>
      <Bounties />
    </>
  );
};

export default BountiesPage;
