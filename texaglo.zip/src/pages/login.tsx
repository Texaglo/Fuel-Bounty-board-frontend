import Login from "@/views/Login";

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;
